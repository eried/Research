Using https://github.com/martinmarinov/TempestSDR
SFX executable by eried